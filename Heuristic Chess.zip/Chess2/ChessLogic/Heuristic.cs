﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChessLogic
{
    public class Heuristic
    {
        public IEnumerable<Move> moves;
        public bool isHeuristics = false;
        private bool flag = false;
        private static Dictionary<PieceType, int> weights = new Dictionary<PieceType, int>()
        {
            [PieceType.King] = 1000,
            [PieceType.Queen] = 90,
            [PieceType.Rook] = 50,
            [PieceType.Bishop] = 33,
            [PieceType.Knight] = 30,
            [PieceType.Pawn] = 10
        };
        private List<(Move, int)> maxOfMax = new List<(Move, int)> ();
        private Dictionary<Position, IEnumerable<Move>> LegalMovesForPos = [];
        private Dictionary<Position, IEnumerable<Move>> HitMovesForPos = [];
        private Dictionary<Position, (Move, int)> secondaryDict = [];
        private Dictionary<Position, Dictionary<Move, int>> nestedDict = [];
        private GameState gameState;
        private GameState testGameState;
        public Heuristic(GameState gameState)
        {
            this.gameState = gameState;
            LegalMovesForPos = FillingDict(LegalMovesForPos, gameState);
            FillingHitDict();
        }

        public Move HeuristicMove(GameState gameState)
        {
            MaxForPos();
            if (maxOfMax.Count > 0)
            {
                (Move, bool) move = findMax();
                if(move.Item2 == false)
                {
                    return move.Item1;
                }
            }
            FillingNestedDict();
            FillingSecondaryDict();
            (Move, int) max = (secondaryDict.FirstOrDefault().Value.Item1, 0);
            foreach (Position pos in secondaryDict.Keys)
            {
                if(max.Item2 < secondaryDict[pos].Item2)
                {
                    max.Item1 = secondaryDict[pos].Item1;
                    max.Item2 = secondaryDict[pos].Item2;
                }

            }
            if (max.Item1 == null)
            {
                return LegalMovesForPos.FirstOrDefault().Value.FirstOrDefault();
            }
            testGameState = new GameState(gameState.CurrentPlayer, gameState.Board.Copy());
            testGameState.Board[max.Item1.ToPos] = testGameState.Board[max.Item1.FromPos];
            testGameState.Board[max.Item1.FromPos] = null;
            moves = testGameState.LegalMovesForPiece(max.Item1.ToPos);
            isHeuristics = true;
            return max.Item1;
        }

        private void FillingSecondaryDict() 
        {
            foreach(Position pos in nestedDict.Keys)
            {
                (Move, int) max = (nestedDict[pos].Keys.FirstOrDefault(), 0);

                foreach (Move move in nestedDict[pos].Keys)
                {
                    if(max.Item2 < nestedDict[pos][move])
                    {
                        max.Item1 = move;
                        max.Item2 = nestedDict[pos][move];
                    } 
                }
                secondaryDict[pos] = max;
            }
        }
        private int testFillingHitDict(Dictionary<Position, IEnumerable<Move>> LegalMoves, GameState game)
        {
            int Count = 0;
            foreach (Position position in LegalMoves.Keys)
            {
                foreach (Move moves in LegalMoves[position])
                {
                    if (game.Board[moves.ToPos] != null)
                    {
                        Count++;
                    }
                }
            }
            return Count;
        }

        private void FillingNestedDict()
        {

            foreach (Position pos in LegalMovesForPos.Keys)
            {
                nestedDict[pos] = new Dictionary<Move, int>();
                Dictionary<Position, IEnumerable<Move>> hitMoves = [];
                foreach (Move move in LegalMovesForPos[pos])
                {
                    testGameState = new GameState(gameState.CurrentPlayer, gameState.Board.Copy());
                    testGameState.Board[move.ToPos] = testGameState.Board[move.FromPos];
                    testGameState.Board[move.FromPos] = null;
                    

                    Dictionary<Position, IEnumerable<Move>> x = [];
                    x = FillingDict(x, testGameState);
                    
                    int z = testFillingHitDict(x, testGameState);

                    
                    nestedDict[pos][move] = z;
                }
            }
        }

        private Dictionary<Position, IEnumerable<Move>> FillingDict(Dictionary<Position, IEnumerable<Move>> LegalMoves, GameState GameState)
        {
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                {
                    Position Pos = new Position(i, j);
                    if (GameState.LegalMovesForPiece(Pos).Any())
                    {
                        LegalMoves[Pos] = GameState.LegalMovesForPiece(Pos);
                    }
                }
            }
            return LegalMoves;
        }

        private void FillingHitDict()
        {
            bool flag = false;
            foreach (Position position in LegalMovesForPos.Keys)
            {
                IEnumerable<Move> hitMoves = [];
                foreach (Move moves in LegalMovesForPos[position])
                {
                    if (gameState.Board[moves.ToPos] != null)
                    {
                        hitMoves = hitMoves.Append(moves);
                        flag = true;
                    }
                }
                if (flag)
                {
                    HitMovesForPos[position] = hitMoves;
                    flag = false;
                }
            }
        }

        private void MaxForPos()
        {
            if (HitMovesForPos.Any())
            {
                foreach (Position pos in HitMovesForPos.Keys)
                {
                    (Move, int) Max = (HitMovesForPos[pos].FirstOrDefault(), 0);
                    foreach (Move move in HitMovesForPos[pos])
                    {
                        if (Max.Item2 < weights[gameState.Board[move.ToPos].Type])
                        {
                            Max.Item1 = move;
                            Max.Item2 = weights[gameState.Board[move.ToPos].Type];
                        }
                        
                    }
                    maxOfMax.Add(Max);
                }
            }
        }

        private (Move, bool) findMax()
        {
            ((Move, int), bool) Max = (maxOfMax[0], false);

            for (int i = 1; i < maxOfMax.Count; i++)
            {
                if (maxOfMax[i].Item2 > Max.Item1.Item2)
                {
                    Max.Item2 = false;
                    Max.Item1 = maxOfMax[i];
                }
                else if(maxOfMax[i].Item2 == Max.Item1.Item2)
                {
                    Max.Item2 = true;
                }
            }
            return (Max.Item1.Item1, Max.Item2);
        }

        

        
    }
}
