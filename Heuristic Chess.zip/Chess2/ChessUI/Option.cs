﻿namespace ChessUI
{
    public enum Option
    {
        Restart,
        Exit,
        Continue
    }
}